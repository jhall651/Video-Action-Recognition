# Machine Learning Engineer Nanodegree
## Specializations
## Project: Capstone Proposal and Capstone Project

The input data for this capstone project can be found at:
http://moments.csail.mit.edu/#download

